#ifndef __ROUTE_H__
#define __ROUTE_H__
#include "map"

void search_route(char *graph[5000], int edge_num, char *condition);


#endif




























